#ifndef BUZZ_CONTROLLER_SET_H
#define BUZZ_CONTROLLER_SET_H

#include <hidapi/hidapi.h>

class BuzzControllerSet  {
private:
   hid_device *device;

public:
	void set_lights(int bitmask);
	BuzzControllerSet(hid_device_info *device_info);
};

#endif
