void register_buzz_controller_manager_types();
void unregister_buzz_controller_manager_types();
