#ifndef BUZZ_CONTROLLER_MANAGER_H
#define BUZZ_CONTROLLER_MANAGER_H

#include "object.h"
#include <hidapi/hidapi.h>
#include "buzz_controller_set.h"

class BuzzControllerManager : public Object {
    GDCLASS(BuzzControllerManager, Object);

    static BuzzControllerManager* singleton;
protected:
    static void _bind_methods();

public:
	static BuzzControllerManager *get_singleton();

	void find_controllers();
	void _process();

    BuzzControllerManager();
};

#endif
