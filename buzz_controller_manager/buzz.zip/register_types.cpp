#include "register_types.h"
#include "class_db.h"
#include "buzz_controller_manager.h"

void register_buzz_controller_manager_types() {

        ClassDB::register_class<BuzzControllerManager>();
}

void unregister_buzz_controller_manager_types() {
   //nothing to do here
}

