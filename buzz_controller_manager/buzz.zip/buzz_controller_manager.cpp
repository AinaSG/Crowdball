#include "buzz_controller_manager.h"
#include "print_string.h"

BuzzControllerManager *BuzzControllerManager::singleton = NULL;

BuzzControllerManager *BuzzControllerManager::get_singleton() {
	if (singleton == NULL) singleton = new BuzzControllerManager();
	return singleton;
}


void BuzzControllerManager::find_controllers() {
	hid_device_info *devices = hid_enumerate(0x054c,0);
	while (devices != nullptr)
	{
		BuzzControllerSet s(devices);
		devices = devices->next;
	}
}

void BuzzControllerManager::_process() {
	print_line("LMAO --- asd");
}

void BuzzControllerManager::_bind_methods() {
    ClassDB::bind_method(D_METHOD("find_controllers"), &BuzzControllerManager::find_controllers);
    ClassDB::bind_method(D_METHOD("_process"), &BuzzControllerManager::_process);
}

BuzzControllerManager::BuzzControllerManager() {
	
}