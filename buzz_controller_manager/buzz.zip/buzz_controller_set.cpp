#include "buzz_controller_set.h"
#include "print_string.h"
#include <iostream>

BuzzControllerSet::BuzzControllerSet(hid_device_info *device_info)
{
	device = hid_open(device_info->vendor_id, device_info->product_id, device_info->serial_number);

	if (device == nullptr) 
	{
		print_line("[ERROR]");
	}
	else 
	{
		print_line("[SUCCESS]");
	}
}
